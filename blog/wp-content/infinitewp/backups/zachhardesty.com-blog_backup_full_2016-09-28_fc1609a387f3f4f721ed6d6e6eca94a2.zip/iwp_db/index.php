<?php
			global $old_url, $old_file_path;
			$old_url = 'http://zachhardesty.com/blog';
			$old_file_path = '/home/fcshar5/public_html/zachhardesty.com/blog/';
			